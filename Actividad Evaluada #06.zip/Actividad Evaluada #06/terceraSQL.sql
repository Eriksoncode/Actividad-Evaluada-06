SELECT * 
FROM products
ORDER BY product_name DESC;
