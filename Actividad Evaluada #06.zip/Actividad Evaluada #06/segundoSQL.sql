SELECT company
FROM customers
WHERE company LIKE '%A';
