SELECT order_id, product_id, unit_price
FROM order_details
WHERE order_id = 46;
